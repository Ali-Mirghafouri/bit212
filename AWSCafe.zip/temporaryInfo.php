<?php
    $showServerInfo = false;
    $timeZone = "GMT+8";
    $currency = "MYR";
    $db_url = "127.0.0.1";
    $db_name = "AWSDB";
    $db_user = "root";
    $db_password = "";
?>