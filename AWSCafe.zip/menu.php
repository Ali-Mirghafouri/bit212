<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Caf&eacute; Menu</title>
<link rel="stylesheet" href="css/styles.css">
<link rel="stylesheet" href="css/menu.css">
</head>

<body class="bodyStyle">

	<div id="header" class="mainHeader">
		<hr>
		<div class="center">Caf&eacute;</div>
	</div>
	<br>
	<?php
		// Get the application environment parameters from the Parameter Store.
		
		include ('getAppParameters.php');
		

		// Display the server metadata information if the showServerInfo parameter is true.
		
		include('serverInfo.php');
		
		//temporary data (actual AWS data is above)
		//include("temporaryInfo.php");
	?>
	<hr>
	<div class="topnav">
		<a href="index.php">Home</a>
		<a href="menu.php" class="active">Menu</a>
		<a href="orderHistory.php">Order History</a>
	</div>

	<div>
		<form action = "processOrder.php" method = "POST">
			<label for = "name">Name: </label><input type = "text" name = "name" id = "name" required><br>
			<label for = "description">Description: </label><textarea name = "description" id = "description"></textarea><br>
			<input type = "submit">
		</form>

	</div>

	<br>
	<div id="Copyright" class="center">
		<h5>&copy;Mom and Pop Caf&eacute;, an AWS Franchise. All rights reserved.</h5>
	</div>
	
</body>
</html>
