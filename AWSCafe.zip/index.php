<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<title>Mom and Pop Malaysia - Home</title>
	<link rel="stylesheet" href="css/styles.css">
</head>

<body class="bodyStyle">

	<div id="header" class="mainHeader">
		<hr>
		<div class="center">Apa Khabar, Malaysia!</div>
	</div>
	<br>
	<?php
		// Get the application environment parameters from the Parameter Store.
		
		include ('getAppParameters.php');
		

		// Display the server metadata information if the showServerInfo parameter is true.
		
		include('serverInfo.php');
		
		//temporary data (actual AWS data is above)
		//include("temporaryInfo.php");
	?>
	<hr>
	<div class="topnav">
		<a href="index.php">Home</a>
		<a href="#ourHistory">Our History</a>
		<a href="#contactUs">Contact Us</a>
		<a href="menu.php">Menu</a>
		<a href="orderHistory.php">Order History</a>
	</div>
	<hr>
	<div id="mainContent">

		<div id="mainPictures" class="center">
			<table>
				<tr>
					<td><img src="images/Coffee-and-Pastries.jpg" height=auto width="490"></td>
					<td><img src="images/Cake-Vitrine.jpg" height=auto width="450"></td>
				</tr>
			</table>
			<hr>
			<p>The Mom and Pop Caf&eacute; finally comes to Malaysia! offers a wide range of European and American caf&eacute; food. Indulge yourself in the delectable taste of our freshly-baked breads, sandwiches, toast, and much more. Complement them with our refreshing teas coffees, and hot chocolates, made with premium ingredients.</p>
			<br>
			<table>
				<tr>
					<td bgcolor="aquamarine">
						<div class="cursiveText">Frank's world-famous cookies, as seen on AWS&trade;</div>
						<table>
							<tr>
								<td><img src="images/Cookies.jpg" height=auto width="300"></td>
							</tr>
						</table>
					</td>
					<td bgcolor="orange">
						<table>
							<tr>
								<td><img src="images/Cup-of-Hot-Chocolate.jpg" height=auto width="200"></td>
								<td class="cursiveText">So,<br>Many,<br>Delicious,<br> Drinks!<br>With or without caffeine!</td>
							</tr>
						</table>
					</td>
					<td bgcolor="aquamarine">
						<div class="cursiveText">Don't forget about our <br/> Insta-Famous Tarts!<br><br>
					  </div>
						<table>
							<tr>
								<td><img src="images/Strawberry-Tarts.jpg" height=auto width="170"></td>
								<td><img src="images/Strawberry-Blueberry-Tarts.jpg" height=auto width="170"></td>
							</tr>
						</table>
					</td>
				</tr>
			</table>
			<hr>
		</div>
	</div>

	<div id="ourHistory" class="center">
		<hr>
		<div>
			<h2>Our History</h2>
		</div>
			<table>
				<tr>
					<td><img src="images/Frank-Martha.jpg" height=auto width="400"></td>
					<td><p>Serving an old family recipe since 2020, Frank and Martha have always been about making people happy. From their humble beginnings in 123 Any Street, the Mom and Pop Caf&eacute; have since opened over 100 locations all over the globe. With quality and passion being at the heart of every sip and bite, you are sure to taste the same joy we've been giving to millions.</p></td>
				</tr>
			</table>
			<hr>
		</div>

	<div id="contactUs" align="center">
		<hr>
		<div>
			<h2>Contact Us</h2>
		</div>
		<table>
			<tr>
				<td><img src="images/Coffee-Shop.jpg" height=auto width="120"></td>
			</tr>
		</table>
		<div><p>321 Jalan Contoh,<br>Bangsar, KL<br><br>Tel: +60-12-345-6789</p></div>
		<div>
			<h3>Hours</h3>
		</div>
		<div>Weekdays: 6:00am - 6:00pm<br>Saturday, Sunday, and Public Holidays: 7:00am - 7:00pm</div>
	</div>

	<div id="Copyright" class="center">
		<h5>&copy;Mom and Pop Caf&eacute;, an AWS Franchise. All rights reserved.</h5>
	</div>
</body>
</html>
