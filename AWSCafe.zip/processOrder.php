<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Caf&eacute; Order Confirmation</title>
<link rel="stylesheet" href="css/styles.css">
</head>

<body class="bodyStyle">

	<div id="header" class="mainHeader">
		<hr>
		<div class="center">Caf&eacute;</div>
	</div>
	<br>
	<?php
		// Get the application environment parameters from the Parameter Store.
		
		include ('getAppParameters.php');
		

		// Display the server metadata information if the showServerInfo parameter is true.
		
		include('serverInfo.php');
		
		//temporary data (actual AWS data is above)
		//include('temporaryInfo.php');
	?>
	<hr>
	<div class="topnav">
		<a href="index.php">Home</a> <a href="menu.php">Menu</a> <a
			href="orderHistory.php">Order History</a>
	</div>

	<hr>
	<div class="cursiveText">
		<p>Order Confirmation</p>
	</div>

<?php

	// Create a connection to the database.

	$conn = new mysqli($db_url, $db_user, $db_password, $db_name);

	// Check the connection.

	if ($conn->connect_error) {
		die("Connection failed: " . $conn->connect_error);
	}

	$name = $_POST["name"];
	$description = $_POST["description"];


	$sql = "SELECT COUNT(*) FROM orders";

	$result = $conn->query($sql)->fetch_assoc();

	$newOrderID = $result['COUNT(*)'];

	$sql = "INSERT INTO orders VALUES($newOrderID, '$name', '$description')";

	if ($conn->query($sql) === TRUE) {
		echo "Your order submission was a success.";
	} else {
		echo "Your order submission failed.";
	}
	$conn->close();


?>
	<br>
	<div id="Copyright" class="center">
		<h5>&copy;Mom and Pop Caf&eacute;, an AWS Franchise. All rights reserved.</h5>
	</div>

</body>
</html>
