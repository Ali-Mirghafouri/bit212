<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Caf&eacute; Order History</title>
<link rel="stylesheet" href="css/styles.css">
</head>

<body class="bodyStyle">

	<div id="header" class="mainHeader">
		<hr>
		<div class="center">Caf&eacute;</div>
	</div>
	<br>
	<?php
		// Get the application environment parameters from the Parameter Store.
		
        include ('getAppParameters.php');
        

		// Display the server metadata information if the showServerInfo parameter is true.
		
        include('serverInfo.php');
        
		//temporary data (actual AWS data is above)
        //include('temporaryInfo.php');
	?>
	<hr>
	<div class="topnav">
		<a href="index.php">Home</a>
		<a href="menu.php">Menu</a>
		<a href="orderHistory.php" class="active">Order History</a>
	</div>

	<hr>
	<div class="cursiveText">
		<p>Order History</p>
	</div>

    

<?php

$conn = new mysqli($db_url, $db_user, $db_password, $db_name);

// Check the connection.
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Retrieve all orders in the database.

$sql = "SELECT * FROM orders";

$result = $conn->query($sql);

if ($result->num_rows > 0) {

    // Display information for each order.

    echo '<table style="width: 80%">';
    echo '<tr>';
    echo '<th>Order No.</th>';
    echo '<th>Name</th>';
    echo '<th>Description</th>';
    echo '</tr>';


    while($row = $result->fetch_assoc()) {
        echo '<tr>';
        echo '<td align="center">' . $row["orderNo"] . '</td>';
        echo '<td align="center">' . $row["name"]. '</td>';
        echo '<td align="center">' .$row["description"] . '</td>';
        echo '</tr>';
    }

    // Close the last table division.
    echo '</table>';

} else {
    echo '<p class="center">You have no orders at this time.</p>';
}

// Close the connection.
$conn->close();
?>

	<br>
	<div id="Copyright" class="center">
		<h5>&copy;Mom and Pop Caf&eacute;, an AWS Franchise. All rights reserved.</h5>
	</div>

</body>
</html>
